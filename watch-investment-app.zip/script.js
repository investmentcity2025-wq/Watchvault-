
let users = JSON.parse(localStorage.getItem('users')) || [];
let investments = JSON.parse(localStorage.getItem('investments')) || [];

function register() {
  const name = document.getElementById('reg-name').value;
  const email = document.getElementById('reg-email').value;
  const pass = document.getElementById('reg-pass').value;
  const msg = document.getElementById('reg-msg');

  if(!name || !email || !pass){
    msg.style.color = 'red';
    msg.textContent = 'Please fill all fields';
    return;
  }

  if(users.find(u => u.email === email)){
    msg.style.color = 'red';
    msg.textContent = 'Email already registered';
    return;
  }

  users.push({name, email, pass});
  localStorage.setItem('users', JSON.stringify(users));
  msg.style.color = 'green';
  msg.textContent = 'Registration successful!';
}

function login() {
  const email = document.getElementById('login-email').value;
  const pass = document.getElementById('login-pass').value;
  const msg = document.getElementById('login-msg');

  const user = users.find(u => u.email === email && u.pass === pass);
  if(user){
    localStorage.setItem('currentUser', JSON.stringify(user));
    window.location.href = 'investor.html';
  } else {
    msg.style.color = 'red';
    msg.textContent = 'Invalid email or password';
  }
}

function invest(amount) {
  const now = new Date();
  const hour = now.getHours();
  const msg = document.getElementById('invest-msg');

  if(hour < 9 || hour >= 18){
    msg.style.color = 'red';
    msg.textContent = 'Withdrawals allowed only from 9 AM to 6 PM';
    return;
  }

  if(amount < 30 || amount > 1500){
    msg.style.color = 'red';
    msg.textContent = 'Investment must be RM30 – RM1500';
    return;
  }

  let user = JSON.parse(localStorage.getItem('currentUser'));
  investments.push({email: user.email, amount: amount, date: new Date().toISOString()});
  localStorage.setItem('investments', JSON.stringify(investments));
  msg.style.color = 'green';
  msg.textContent = `Invested RM${amount} successfully! Daily profit 30% will apply.`;
}

function calculateProfit(email){
  const userInvestments = investments.filter(inv => inv.email === email);
  return userInvestments.map(inv => {
    const days = Math.floor((new Date() - new Date(inv.date)) / (1000*60*60*24));
    const profit = inv.amount * 0.3 * days;
    return {amount: inv.amount, profit};
  });
}
